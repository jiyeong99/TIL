-- SQLite
-- create table classmate
CREATE TABLE classmates(
  id INTEGER PRIMARY KEY,
  name TEXT );
.table